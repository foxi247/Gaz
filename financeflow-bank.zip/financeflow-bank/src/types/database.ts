// Future Supabase schema types. Replace with generated types from:
// npx supabase gen types typescript --project-id <project-id> > src/types/database.ts

export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export interface Database {
  public: {
    Tables: {
      users: {
        Row: { id: string; full_name: string; email: string; avatar_url: string | null; created_at: string };
        Insert: { id?: string; full_name: string; email: string; avatar_url?: string | null; created_at?: string };
        Update: { full_name?: string; email?: string; avatar_url?: string | null };
      };
      accounts: {
        Row: { id: string; user_id: string; name: string; type: string; balance: number; currency: string; created_at: string };
        Insert: { id?: string; user_id: string; name: string; type: string; balance?: number; currency?: string; created_at?: string };
        Update: { name?: string; type?: string; balance?: number; currency?: string };
      };
      transactions: {
        Row: { id: string; user_id: string; account_id: string; type: 'income' | 'expense' | 'transfer'; category: string; amount: number; title: string; description: string | null; status: string; created_at: string };
        Insert: { id?: string; user_id: string; account_id: string; type: 'income' | 'expense' | 'transfer'; category: string; amount: number; title: string; description?: string | null; status?: string; created_at?: string };
        Update: { category?: string; amount?: number; title?: string; description?: string | null; status?: string };
      };
      transfers: {
        Row: { id: string; sender_user_id: string; receiver_user_id: string | null; from_account_id: string; to_account_id: string | null; amount: number; comment: string | null; status: string; created_at: string };
        Insert: { id?: string; sender_user_id: string; receiver_user_id?: string | null; from_account_id: string; to_account_id?: string | null; amount: number; comment?: string | null; status?: string; created_at?: string };
        Update: { status?: string; comment?: string | null };
      };
      categories: {
        Row: { id: string; user_id: string; name: string; type: string; color: string; icon: string | null };
        Insert: { id?: string; user_id: string; name: string; type: string; color: string; icon?: string | null };
        Update: { name?: string; type?: string; color?: string; icon?: string | null };
      };
    };
  };
}
