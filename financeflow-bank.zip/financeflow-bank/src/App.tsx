import { useMemo, useState } from 'react';
import { Sidebar } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { MobileNav } from './components/layout/MobileNav';
import { Toast } from './components/Toast';
import { user, accounts as initialAccounts, transactions as initialTransactions, monthlyData, categorySpend } from './data/mockData';
import type { Account, PageKey, Transaction, TransferPayload } from './types/finance';
import { Dashboard } from './pages/Dashboard';
import { Accounts } from './pages/Accounts';
import { Transactions } from './pages/Transactions';
import { Transfer } from './pages/Transfer';
import { Analytics } from './pages/Analytics';
import { Settings } from './pages/Settings';
import { useToast } from './hooks/useToast';

const pageTitles: Record<PageKey, string> = {
  dashboard: 'Dashboard',
  accounts: 'Accounts',
  transactions: 'Transactions',
  transfer: 'Transfer',
  analytics: 'Analytics',
  settings: 'Settings'
};

export default function App() {
  const [activePage, setActivePage] = useState<PageKey>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [accounts, setAccounts] = useState<Account[]>(initialAccounts);
  const [transactions, setTransactions] = useState<Transaction[]>(initialTransactions);
  const [selectedAccountId, setSelectedAccountId] = useState(initialAccounts[0].id);
  const { message, showToast } = useToast();

  const sortedTransactions = useMemo(
    () => [...transactions].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()),
    [transactions]
  );

  function handleNavigate(page: PageKey) {
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function handleTransfer(payload: TransferPayload) {
    setAccounts((current) => current.map((account) => account.id === payload.fromAccountId ? { ...account, balance: account.balance - payload.amount } : account));
    const newTransaction: Transaction = {
      id: `tx_${Date.now()}`,
      userId: user.id,
      accountId: payload.fromAccountId,
      type: 'transfer',
      category: 'Transfer',
      amount: payload.amount,
      title: `Transfer to ${payload.receiver}`,
      description: payload.comment || 'Outgoing transfer',
      status: 'completed',
      createdAt: new Date().toISOString(),
      merchant: payload.receiver
    };
    setTransactions((current) => [newTransaction, ...current]);
    showToast('Transfer sent successfully');
  }

  return (
    <div className="min-h-dvh bg-mist text-graphite">
      <div className="mx-auto flex max-w-[1520px] gap-5 lg:p-6">
        <Sidebar activePage={activePage} onNavigate={handleNavigate} open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <main className="min-w-0 flex-1 px-4 pb-28 pt-3 sm:px-6 lg:px-0 lg:pb-0 lg:pt-0">
          <Header user={user} title={pageTitles[activePage]} onMenu={() => setSidebarOpen(true)} />
          {activePage === 'dashboard' && <Dashboard user={user} accounts={accounts} transactions={sortedTransactions} monthlyData={monthlyData} categorySpend={categorySpend} onQuickAction={handleNavigate} />}
          {activePage === 'accounts' && <Accounts accounts={accounts} selectedAccountId={selectedAccountId} onSelectAccount={setSelectedAccountId} />}
          {activePage === 'transactions' && <Transactions transactions={sortedTransactions} />}
          {activePage === 'transfer' && <Transfer accounts={accounts} onTransfer={handleTransfer} />}
          {activePage === 'analytics' && <Analytics monthlyData={monthlyData} categorySpend={categorySpend} transactions={sortedTransactions} />}
          {activePage === 'settings' && <Settings user={user} />}
        </main>
      </div>
      <MobileNav activePage={activePage} onNavigate={handleNavigate} />
      <Toast message={message} />
    </div>
  );
}
