import { AccountCard, NewAccountCard } from '../components/AccountCard';
import type { Account } from '../types/finance';

interface AccountsProps { accounts: Account[]; selectedAccountId: string; onSelectAccount: (id: string) => void; }

export function Accounts({ accounts, selectedAccountId, onSelectAccount }: AccountsProps) {
  return (
    <div className="grid gap-5">
      <section className="glass-card p-5 sm:p-7">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <h2 className="text-2xl font-extrabold tracking-tight">Your balances</h2>
            <p className="mt-1 text-sm text-muted">Choose an account and prepare future account-level analytics.</p>
          </div>
          <button className="pressable rounded-2xl bg-graphite px-5 py-3 font-extrabold text-white shadow-card">Create new account</button>
        </div>
      </section>
      <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
        {accounts.map((account) => <AccountCard key={account.id} account={account} active={selectedAccountId === account.id} onSelect={onSelectAccount} />)}
        <NewAccountCard />
      </div>
    </div>
  );
}
