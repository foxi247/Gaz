import type { UserProfile } from '../types/finance';

interface SettingsProps { user: UserProfile; }

export function Settings({ user }: SettingsProps) {
  return (
    <div className="grid gap-5 xl:grid-cols-[.9fr_1.1fr]">
      <section className="glass-card p-6">
        <h2 className="text-2xl font-extrabold">Profile</h2>
        <div className="mt-6 flex items-center gap-4">
          <img src={user.avatarUrl} alt={user.fullName} className="h-20 w-20 rounded-[24px] object-cover" />
          <div><p className="text-xl font-extrabold">{user.fullName}</p><p className="text-sm text-muted">{user.email}</p></div>
        </div>
        <div className="mt-6 grid gap-4">
          <label className="grid gap-2 text-sm font-bold">Full name<input defaultValue={user.fullName} className="focus-ring rounded-2xl border border-neutral-200 px-4 py-3" /></label>
          <label className="grid gap-2 text-sm font-bold">Email<input defaultValue={user.email} className="focus-ring rounded-2xl border border-neutral-200 px-4 py-3" /></label>
        </div>
      </section>
      <section className="glass-card p-6">
        <h2 className="text-2xl font-extrabold">Preferences</h2>
        <div className="mt-6 grid gap-4 md:grid-cols-2">
          <label className="grid gap-2 text-sm font-bold">Currency<select className="focus-ring rounded-2xl border border-neutral-200 px-4 py-3"><option>USD</option><option>EUR</option><option>UZS</option><option>RUB</option></select></label>
          <label className="grid gap-2 text-sm font-bold">Theme<select className="focus-ring rounded-2xl border border-neutral-200 px-4 py-3"><option>Light premium</option><option>System</option><option>Dark</option></select></label>
          <label className="grid gap-2 text-sm font-bold">Monthly limit<input defaultValue="4200" className="focus-ring rounded-2xl border border-neutral-200 px-4 py-3" /></label>
          <label className="grid gap-2 text-sm font-bold">Notifications<select className="focus-ring rounded-2xl border border-neutral-200 px-4 py-3"><option>Enabled</option><option>Only security</option><option>Disabled</option></select></label>
        </div>
        <div className="mt-6 rounded-[24px] bg-neutral-100 p-5"><h3 className="font-extrabold">Security</h3><p className="mt-1 text-sm text-muted">MFA, device sessions and password reset flows can be connected after Supabase Auth is added.</p></div>
      </section>
    </div>
  );
}
