import { Brain, CalendarDays, PiggyBank, TrendingDown } from 'lucide-react';
import { ChartCard } from '../components/ChartCard';
import { BarChart } from '../components/charts/BarChart';
import { DonutChart } from '../components/charts/DonutChart';
import type { CategorySpend, MonthlyPoint, Transaction } from '../types/finance';
import { formatCurrency } from '../utils/format';

interface AnalyticsProps { monthlyData: MonthlyPoint[]; categorySpend: CategorySpend[]; transactions: Transaction[]; }

export function Analytics({ monthlyData, categorySpend, transactions }: AnalyticsProps) {
  const expense = transactions.filter((tx) => tx.type === 'expense').reduce((sum, tx) => sum + tx.amount, 0);
  const averageDaily = expense / 30;
  const latestMonth = monthlyData[monthlyData.length - 1];
  const forecast = latestMonth.income - latestMonth.expense + 23902;

  return (
    <div className="grid gap-5">
      <div className="grid gap-4 md:grid-cols-3">
        {[
          { icon: TrendingDown, title: 'Expense trend', value: '12% lower', text: 'You spent less than last month.' },
          { icon: CalendarDays, title: 'Daily average', value: formatCurrency(averageDaily), text: 'Average daily spending this month.' },
          { icon: PiggyBank, title: 'Balance forecast', value: formatCurrency(forecast), text: 'Projected end-of-month balance.' }
        ].map((item) => <section key={item.title} className="glass-card p-5"><item.icon className="h-6 w-6 text-success" /><h3 className="mt-5 text-sm font-bold text-muted">{item.title}</h3><p className="mt-1 text-2xl font-extrabold">{item.value}</p><p className="mt-2 text-sm text-muted">{item.text}</p></section>)}
      </div>
      <div className="grid gap-5 xl:grid-cols-[1.55fr_.85fr]">
        <ChartCard title="Financial pulse" subtitle="Income and expense comparison">
          <BarChart data={monthlyData} />
        </ChartCard>
        <ChartCard title="Category split" action={false}>
          <DonutChart data={categorySpend} />
        </ChartCard>
      </div>
      <section className="glass-card p-6">
        <h2 className="flex items-center gap-2 text-xl font-extrabold"><Brain className="h-5 w-5" /> Smart insights</h2>
        <div className="mt-5 grid gap-3 md:grid-cols-3">
          {['You spent 12% less than last month.', 'Housing is 38% of current expenses.', 'Savings growth is ahead of your plan.'].map((text) => (
            <div key={text} className="rounded-2xl bg-neutral-100 p-4 text-sm font-bold text-graphite">{text}</div>
          ))}
        </div>
      </section>
    </div>
  );
}
