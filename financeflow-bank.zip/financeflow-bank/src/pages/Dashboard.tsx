import { Activity, ArrowDownRight, ArrowUpRight, Landmark, ReceiptText } from 'lucide-react';
import { Account, CategorySpend, MonthlyPoint, Transaction, UserProfile } from '../types/finance';
import { StatCard } from '../components/StatCard';
import { ChartCard } from '../components/ChartCard';
import { BarChart } from '../components/charts/BarChart';
import { DonutChart } from '../components/charts/DonutChart';
import { TransactionTable } from '../components/TransactionTable';
import { formatCurrency } from '../utils/format';

interface DashboardProps {
  user: UserProfile;
  accounts: Account[];
  transactions: Transaction[];
  monthlyData: MonthlyPoint[];
  categorySpend: CategorySpend[];
  onQuickAction: (page: 'transfer' | 'transactions') => void;
}

export function Dashboard({ user, accounts, transactions, monthlyData, categorySpend, onQuickAction }: DashboardProps) {
  const balance = accounts.reduce((sum, account) => sum + account.balance, 0);
  const income = transactions.filter((tx) => tx.type === 'income').reduce((sum, tx) => sum + tx.amount, 0);
  const expenses = transactions.filter((tx) => tx.type !== 'income').reduce((sum, tx) => sum + tx.amount, 0);
  const profit = income - expenses;

  return (
    <div className="grid gap-5">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard title="Total Balance" value={balance} trend={4.2} icon={Landmark} dark currency={user.currency} />
        <StatCard title="Monthly Income" value={income} trend={7.1} icon={ArrowDownRight} currency={user.currency} />
        <StatCard title="Monthly Expense" value={expenses} trend={-2.9} icon={ArrowUpRight} currency={user.currency} />
        <StatCard title="Net Profit" value={profit} trend={3.6} icon={Activity} currency={user.currency} />
      </div>

      <div className="grid gap-5 xl:grid-cols-[1.6fr_1fr]">
        <ChartCard title="Income & expense flow" subtitle="Monthly overview with clean mock analytics">
          <BarChart data={monthlyData} />
        </ChartCard>
        <div className="grid gap-5">
          <section className="glass-card p-5 sm:p-6">
            <h2 className="text-xl font-bold">Quick actions</h2>
            <div className="mt-5 grid grid-cols-2 gap-3">
              {['Top up', 'Transfer', 'Pay bills', 'Add expense'].map((label) => (
                <button key={label} onClick={() => onQuickAction(label === 'Transfer' ? 'transfer' : 'transactions')} className="pressable rounded-2xl bg-neutral-100 px-4 py-4 text-sm font-extrabold transition hover:bg-graphite hover:text-white">{label}</button>
              ))}
            </div>
          </section>
          <ChartCard title="Expense categories" action={false}>
            <DonutChart data={categorySpend} />
          </ChartCard>
        </div>
      </div>

      <section className="glass-card p-5 sm:p-6">
        <div className="mb-5 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold">Latest transactions</h2>
            <p className="text-sm text-muted">{transactions.length} operations this month · {formatCurrency(profit, user.currency)} net</p>
          </div>
          <ReceiptText className="h-6 w-6 text-muted" />
        </div>
        <TransactionTable transactions={transactions.slice(0, 5)} />
      </section>
    </div>
  );
}
