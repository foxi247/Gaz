// Supabase integration placeholder.
// 1. Install: npm i @supabase/supabase-js
// 2. Add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to .env.local
// 3. Uncomment and use the typed client below.

// import { createClient } from '@supabase/supabase-js';
// import type { Database } from '../types/database';
//
// const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
// const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
//
// export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey);

export const supabaseNotConfigured = true;
