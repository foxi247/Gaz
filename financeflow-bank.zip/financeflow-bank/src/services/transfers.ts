import type { TransferPayload } from '../types/finance';

// Future implementation should use a Supabase RPC or Edge Function so debiting,
// crediting and transaction history are committed atomically.
export async function sendTransfer(_payload: TransferPayload): Promise<{ id: string; status: 'completed' | 'pending' }> {
  throw new Error('Connect Supabase before sending persisted transfers.');
}
