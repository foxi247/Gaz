import type { Transaction } from '../types/finance';

// Future implementation: read from transactions table with filters and pagination.
export async function getTransactions(_userId: string): Promise<Transaction[]> {
  throw new Error('Supabase is not connected yet. Use mock data until integration is enabled.');
}

export async function createTransaction(_transaction: Omit<Transaction, 'id'>): Promise<Transaction> {
  throw new Error('Connect Supabase before creating persisted transactions.');
}
