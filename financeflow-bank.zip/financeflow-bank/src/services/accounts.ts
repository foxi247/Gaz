import type { Account } from '../types/finance';

// Supabase-ready service boundary. Later replace mock state calls with:
// const { data, error } = await supabase.from('accounts').select('*').eq('user_id', userId)
export async function getAccounts(_userId: string): Promise<Account[]> {
  throw new Error('Supabase is not connected yet. Use mock data until integration is enabled.');
}

export async function createAccount(_payload: Pick<Account, 'name' | 'type' | 'currency'>): Promise<Account> {
  throw new Error('Connect Supabase before creating persisted accounts.');
}
